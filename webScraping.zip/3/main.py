from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import csv
#driver = webdriver.Chrome()
csv_file = open("unity_links5.csv", "w")
csv_writer = csv.writer(csv_file)
for i in range(335,868):
    chr_options = Options()
    chr_options.add_experimental_option("detach", True)
    chr_driver = webdriver.Chrome(options=chr_options)
    chr_driver.get(f"https://assetstore.unity.com/?orderBy=1&page={i}&rows=96")
    soup = BeautifulSoup(chr_driver.page_source, "html.parser")
    links = soup.find_all("div", {"class": "_3zZYp"})

    for link in links:
        a_tag = link.find("a")
        a_tag = a_tag.get("href")
        csv_writer.writerow([a_tag])
    chr_driver.close()
csv_file.close()
    #for link in links:
 #   a = link.find("img")
  #  b = a.get("src")
   # #links = links.split("=")#print(type(links))
    #print(links)
