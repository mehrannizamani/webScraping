from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import pandas as pd
import csv

csv_file = open("asset1.csv", "w")
csv_writer = csv.writer(csv_file)
csv_writer.writerow(["Name", "Latin Name", "Link Description", "Corresponding Image"])
chr_options = Options()
chr_options.add_experimental_option("detach", True)
chr_driver = webdriver.Chrome(options=chr_options)

url = "https://clutch.co/ca/agencies/digital-marketing?page=0"
chr_driver.get(url)
soup = BeautifulSoup(chr_driver.page_source, "html.parser")

all_com = soup.find("div", {"class": "list_wrap"})
list_rows = all_com.find_all("li", {"class": "provider provider-row sponsor"})
list_rows1 = all_com.find_all("li", {"class": "provider provider-row"})
link_list = []
name_list = []
service_list = []
for data in list_rows:
    name = data.find("a", {"class": "company_title directory_profile"}).text
    name = name.strip()
    link = data.find("a", {"class": "website-link__item"})["href"]
    link_list.append(link)
    name_list.append(name)
    service = data.find_all("span")[7].text
    service_list.append(service)





for data in list_rows1:
    name1 = data.find("a", {"class": "company_title directory_profile"}).text
    name1 = name1.strip()
    link1 = data.find("a", {"class": "website-link__item"})["href"]
    link_list.append(link1)
    name_list.append(name1)
    service1 = data.find_all("span")[7].text
    service_list.append(service)
#name = name + name1
print(len(service_list))

chr_driver.close()
# species = soup.find_all("div", class_ = "col-md-4 col-xs-6 marginTop20")
# for fish in species:
#     image = fish.find("span", class_ = "pull-right")
#     image = image.find("img")
#     image = image.get("src")
#     a_tag = fish.find_all("a")
#     a_tag = a_tag[1]
#     links = a_tag.get("href")
#     latin_name = a_tag.find("em").text
#     name = a_tag.text
#     name = name.strip()
#     name = name.split("\n")
#     name = name[0]
#     csv_writer.writerow([name, latin_name, links, image])
#     print(name)


