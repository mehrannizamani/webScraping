import urllib.request
from urllib.request import urlopen
from bs4 import BeautifulSoup
import requests

url = "https://www.tntsupermarket.com/eng/product-categories/snacks.html"
page = requests.get(url)
page = page.content
soup = BeautifulSoup(page, "html.parser")


images = soup.find_all("img")
print(images)
i = 1

# for image in images:
#     image = image.find("img")["src"]
    #print(image)
    # file_name = i
    # image_file = open(str(file_name)+".jpg", "wb")
    # image_file.write(urllib.request.urlopen(image).read())
    # image_file.close()
    # i = i+1
