from bs4 import BeautifulSoup
import requests
import pandas as pd
import csv

csv_file = open("asset1.csv", "w")
csv_writer = csv.writer(csv_file)
csv_writer.writerow(["Name", "Latin Name", "Link Description", "Corresponding Image"])


url = "https://doris.ffessm.fr/find/species/(offset)/21"
page = requests.get(url)
page = page.content
soup = BeautifulSoup(page, "html.parser")

species = soup.find_all("div", class_ = "col-md-4 col-xs-6 marginTop20")
for fish in species:
    image = fish.find("span", class_ = "pull-right")
    image = image.find("img")
    image = image.get("src")
    a_tag = fish.find_all("a")
    a_tag = a_tag[1]
    links = a_tag.get("href")
    latin_name = a_tag.find("em").text
    name = a_tag.text
    name = name.strip()
    name = name.split("\n")
    name = name[0]
    csv_writer.writerow([name, latin_name, links, image])
    print(name)


