import csv
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
# is code se link open hote hen csv file k through
def unicode_csv_reader(utf8_data, dialect=csv.excel, **kwargs):
    csv_reader = csv.reader(utf8_data, dialect=dialect, **kwargs)
    for row in csv_reader:
        yield [unicode(cell, 'utf-8') for cell in row]


# Open the CSV file
with open('TXT.csv', 'r') as f:
    reader = csv.reader(f)
    urls = [row[0] for row in reader]
chr_options = Options()
chr_options.add_experimental_option("detach", True)
chr_driver = webdriver.Chrome(options=chr_options)
# Launch the browser

csv_file = open("asset1.csv", "w")
csv_writer = csv.writer(csv_file)
csv_writer.writerow(["Title", "Views", "Price"])

# Loop through the URLs and open each one
for url in urls:
    chr_driver.get(url)
    soup = BeautifulSoup(chr_driver.page_source, "html.parser")
    price = soup.find("div", {"class":"mErEH _223RA"}).text
    views = soup.find("b").text
    views = views.split(" ")
    views = views[0]
    title = soup.find("div", {"class" :"_2-4Q8"})
    title = title.find("h1").text
    csv_writer.writerow([title, views, price])


csv_file.close

    # Do something on the webpage here
    # ...

# Close the browser

