from bs4 import BeautifulSoup
import requests
import csv
csv_file = open("cmscsv1.csv", "w")
csv_writer = csv.writer(csv_file)
csv_writer.writerow(["Headline", "Summary", "Videolink"])
tutorials = []
for i in range(1,18):
    source = requests.get(f"http://coreyms.com/page/{i}").text
    soup = BeautifulSoup(source, "lxml")

    articles = soup.find_all("article")


    for article in articles:
        title = article.header.h2.a.text
        print(title)
        discriiption = article.div.p.text
        print(discriiption)
        try:
            vid_scr = article.find("iframe", class_="youtube-player")["src"]
            vid_id = vid_scr.split("/")[4]
            vid_id = vid_id.split("?")[0]
            yt_link = f"https://youtube.com/watch?v={vid_id}"
            print(yt_link)
        except Exception as e:
            yt_link = None
        print()
        csv_writer.writerow([title, discriiption, yt_link])
csv_file.close()

