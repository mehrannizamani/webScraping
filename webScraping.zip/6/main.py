import urllib.request
from urllib.request import urlopen
from bs4 import BeautifulSoup
import requests

url = "https://www.ebay.com/sch/i.html?_from=R40&_nkw=led&_sacat=0&LH_TitleDesc=0&_ipg=60"
page = urllib.request.urlopen(url)
soup = BeautifulSoup(page, "lxml")
image_list = soup.find("div", class_ = "srp-river-results clearfix")
images = image_list.find_all("div", class_="s-item__wrapper clearfix")

i = 1

for image in images:
    image = image.find("img")["src"]
    file_name = i
    image_file = open(str(file_name)+".jpg", "wb")
    image_file.write(urllib.request.urlopen(image).read())
    image_file.close()
    i = i+1
